import numpy as np
def get_working_set(z, C, sigma):
    threshold = np.sqrt(2 * C / sigma)
    return np.where((z > 0) & (z <= threshold))[0]

