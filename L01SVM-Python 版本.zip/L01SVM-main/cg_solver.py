import numpy as np

def conjugate_gradient(AT, sigma, b, n, flag):
    x = np.zeros(n)
    r = b.copy()
    e = np.dot(r, r)
    t = e
    for i in range(50):
        if e < 1e-10 * t:
            break
        p = r if i == 0 else r + (e / e0) * p
        if flag == 1:
            w = p / sigma + AT.T @ (AT @ p)
        else:
            w = p / sigma + AT @ (AT.T @ p)
        a = e / np.dot(p, w)
        x += a * p
        r -= a * w
        e0 = e
        e = np.dot(r, r)
    return x
