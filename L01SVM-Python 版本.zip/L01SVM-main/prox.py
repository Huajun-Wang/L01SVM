import numpy as np
def prox_operator(z, C, sigma):
    threshold = np.sqrt(2 * C / sigma)
    u = np.copy(z)
    mask = (z > 0) & (z <= threshold)
    u[mask] = 0
    return u, mask
