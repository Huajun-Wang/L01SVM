import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from l01admm import l01_admm
from scipy.io import loadmat
import time



# 数据加载和预处理
mat = loadmat(r"C:\Users\27181\Downloads\L01ADMM\L01ADMM\solver\Austrain.mat")
X = mat['X']
y = mat['Y'].flatten()
y[y == 0] = -1
X = StandardScaler().fit_transform(X)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# 参数网格
C_list = [0.01, 0.02, 0.03, 0.06, 0.12, 0.25, 0.5, 1.0, 2.0, 4.0, 8.0, 16.0, 32.0, 64.0, 128.0]
sigma_list = [0.088, 0.125, 0.177, 0.25, 0.354, 0.5, 0.707, 1.0, 1.414, 2.0, 2.828, 4.0, 5.657, 8.0, 11.314]

train_acc_grid = np.zeros((len(C_list), len(sigma_list)))
test_acc_grid = np.zeros((len(C_list), len(sigma_list)))

print(f"{'|':<2}{'C':^7}|{'sigma':^8}|{'Iter':^6}|{'TrainACC':^10}|{'TestACC':^9}|{'#SV':^5}|{'Time(s)':^9}|")
print(f"{'|':<2}{'-'*7}|{'-'*8}|{'-'*6}|{'-'*10}|{'-'*9}|{'-'*5}|{'-'*9}|")

# 网格搜索
for i, C in enumerate(C_list):
    for j, sigma in enumerate(sigma_list):
        start = time.time()
        w, b, train_acc, iters, T = l01_admm(X_train, y_train, C=C, sigma=sigma, max_iter=1000, tol=1e-3)
        end = time.time()
        y_pred_test = np.sign(X_test @ w + b)
        test_acc = np.mean(y_pred_test == y_test)

        train_acc_grid[i, j] = train_acc
        test_acc_grid[i, j] = test_acc

        print(f"| {C:5.2f} | {sigma:6.3f} | {iters:4d} | {train_acc:8.4f} | {test_acc:7.4f} | {len(T):3d} | {end - start:7.3f} |")


