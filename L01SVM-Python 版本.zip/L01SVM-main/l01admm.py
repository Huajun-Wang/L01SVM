import numpy as np
from numpy.linalg import norm
from get_t import get_working_set


def l01_admm(X, y, C=1.0, sigma=1.0, max_iter=1000, tol=1e-3):
    m, n = X.shape
    w = np.zeros(n)
    A = y[:, None] * X
    b = 0.0
    lam = np.zeros(m)
    u = np.zeros(m)

    lamsig = lam / sigma
    z = np.copy(u - lamsig)
    T = get_working_set(z, C, sigma)

    iter_count = 0
    tACC = []

    while iter_count < max_iter:
        iter_count += 1

        u_old = u.copy()
        if len(T) > 0:
            u = z.copy()
            u[T] = 0
        else:
            tmp1 = np.sqrt(2 * C / sigma)
            T = np.where((z > 0) & (z <= tmp1))[0]
            u = z.copy()
            u[T] = 0

        # Update w
        tmp = 1 - u - lamsig
        v = tmp - b * y

        AT = A[T, :]
        yT = y[T]
        vT = v[T]

        if len(T) > 0:
            if n <= len(T):
                AAT = AT.T @ AT + (1 / sigma) * np.eye(n)
                w = np.linalg.solve(AAT, AT.T @ vT)
            else:
                AAT = AT @ AT.T + (1 / sigma) * np.eye(len(T))
                w = AT.T @ np.linalg.solve(AAT, vT)
        else:
            w = -np.ones(n)

        # Update b
        Aw = A @ w
        if len(T) > 0:
            b = np.mean((tmp[T] - Aw[T]) * yT)
        else:
            b = 0.0

        # Update lambda
        omega = Aw + u - 1 + b * y
        lam[T] = lam[T] + sigma * omega[T]
        lamsig = lam / sigma

        # Compute stopping criteria
        ulam = u - lamsig
        ind = (ulam <= 0) | (ulam > np.sqrt(2 * C / sigma))
        theta1 = norm(w + A[T, :].T @ lam[T]) / (1 + norm(w))
        theta2 = np.abs(yT @ lam[T]) / (1 + len(T))
        theta3 = norm(omega) / (m + norm(Aw))
        theta4 = norm(u - ulam * ind) / (1 + norm(u))
        error = max(theta1, theta2, theta3, theta4)

        # Accuracy
        pred = np.sign(Aw + b)
        acc = np.mean(pred == y)
        tACC.append(acc)

        # Convergence check
        if error < tol and acc > 0.5:
            break

        # Update z
        z = ulam - omega
        z_pos = z[z > 0]
        sig0 = np.min(z_pos) if z_pos.size > 0 else 1e-8

        # σ adjustment every 10 iterations
        if iter_count % 10 == 0:
            if theta3 > 1e-3:
                sigma = min(sigma * 2, 10)
            elif theta1 > 1e-3:
                sigma = min(max(0.01, sigma / 1.25), 5)

        # Optional: reset T based on z stability
        if iter_count > 5 and m > n and m <= 10000:
            if len(tACC) >= 4 and np.std(tACC[-4:]) <= 1e-3:
                Cons = np.sqrt(2 * C / sigma)
                m0 = max(20, 2 * n)
                T0 = np.where((z > 0) & (z <= Cons))[0]
                if len(T0) < 5 or len(T0) >= m0:
                    z1 = z[z > 0]
                    if len(z1) > m0:
                        s = np.sort(z1)[:m0]
                        sigma = min(2 * C / (s[-1] ** 2), 10000)
                    else:
                        T = np.argsort(np.abs(z))[:m0]

    return w, b, acc, iter_count, T
